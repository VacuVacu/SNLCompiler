package lex;

public class LexItem {

    public final static int ENDFILE = -1;
    public final static int ERROR = -2;
    public final static int PROGRAM = -3;
    public final static int PROCEDURE = -4;
    public final static int TYPE = -5;
    public final static int VAR = -6;
    public final static int IF = -7;
    public final static int THEN = -8;
    public final static int ELSE = -9;
    public final static int FI = -10;
    public final static int DO = -11;
    public final static int WHILE = -12;
    public final static int ENDWH = -13;
    public final static int BEGIN = -14;
    public final static int END = -15;
    public final static int READ = -16;
    public final static int WRITE = -17;
    public final static int ARRAY = -18;
    public final static int OF = -19;
    public final static int RECORD = -20;
    public final static int RETURN = -21;
    public final static int INTEGER = -22;
    public final static int CHAR = -23;
    public final static int ID = -24;
    public final static int INTC = -25;
    public final static int CHARC = -26;
    public final static int ASSIGN = -27;
    public final static int EQ = -28;
    public final static int LT = -29;
    public final static int GT = -30;
    public final static int PLUS = -31;
    public final static int MINUS = -32;
    public final static int TIMES = -33;
    public final static int OVER = -34;
    public final static int LPAREN = -35;
    public final static int RPAREN = -36;
    public final static int DOT = -37;
    public final static int COLON = -38;
    public final static int SEMI = -39;
    public final static int COMMA = -40;
    public final static int LMIDPAREN = -41;
    public final static int RMIDPAREN = -42;
    public final static int UNDERANGE = -43;
    public final static int COMMENT = -44;

}
