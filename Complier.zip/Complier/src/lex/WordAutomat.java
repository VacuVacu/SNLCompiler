package lex;


import utils.LexException;

import java.util.ArrayList;
import java.util.List;

//词法分析器
public class WordAutomat {
    int line=1;  //行号
    int cursor=0; //字符串当前处理位置
    int comment=0;
    List<Token> tokenList = new ArrayList<>();
    private ReservedWord[] reservedWord = new ReservedWord[] {
            new ReservedWord(LexItem.PROGRAM,"program"),
            new ReservedWord(LexItem.TYPE,"type"),
            new ReservedWord(LexItem.VAR,"var"),
            new ReservedWord(LexItem.PROCEDURE,"procedure"),
            new ReservedWord(LexItem.BEGIN,"begin"),
            new ReservedWord(LexItem.END,"end"),
            new ReservedWord(LexItem.ARRAY,"array"),
            new ReservedWord(LexItem.OF,"of"),
            new ReservedWord(LexItem.RECORD,"record"),
            new ReservedWord(LexItem.IF,"if"),
            new ReservedWord(LexItem.THEN,"then"),
            new ReservedWord(LexItem.ELSE,"else"),
            new ReservedWord(LexItem.FI,"fi"),
            new ReservedWord(LexItem.WHILE,"while"),
            new ReservedWord(LexItem.DO,"do"),
            new ReservedWord(LexItem.ENDWH,"endwh"),
            new ReservedWord(LexItem.READ,"read"),
            new ReservedWord(LexItem.WRITE,"write"),
            new ReservedWord(LexItem.RETURN,"return"),
            new ReservedWord(LexItem.INTEGER,"integer"),
            new ReservedWord(LexItem.CHAR,"char")
    };

    public Token getToken(int index){
        if(index>=tokenList.size()){
            return null;
        }
        return tokenList.get(index);
    }

    public int getCommentNums(){
        return this.comment;
    }

    public int getTokenNums(){
        return tokenList.size();
    }

    public List<Token> getTokenList() {
        return tokenList;
    }

    protected int isReserved(String reserved) {
        for (int i = 0; i < reservedWord.length; i++) {
            if (reservedWord[i].getContent().equals(reserved))
                return reservedWord[i].getLexType();
        }
        return LexItem.ID;
    }

    public void displayTokenList(){
        System.out.println("token序列如下:   ");
        for (int i = 0; i < tokenList.size(); i++) {
            System.out.print(tokenList.get(i).getLine() + ": ");
            switch (tokenList.get(i).getLexType()) {
                case LexItem.ASSIGN:
                case LexItem.EQ:
                case LexItem.LT:
                case LexItem.GT:
                case LexItem.PLUS:
                case LexItem.MINUS:
                case LexItem.TIMES:
                case LexItem.OVER:
                case LexItem.LPAREN:
                case LexItem.RPAREN:
                case LexItem.DOT:
                case LexItem.COMMA:
                case LexItem.SEMI:
                case LexItem.LMIDPAREN:
                case LexItem.RMIDPAREN:
                case LexItem.UNDERANGE:
                    System.out.println(tokenList.get(i).getSeminfo());
                    break;
                case LexItem.ID:
                    System.out.println("ID, name = " + tokenList.get(i).getSeminfo());
                    break;
                case LexItem.INTC:
                    System.out.println("INTC, value = " + tokenList.get(i).getSeminfo());
                    break;
                case LexItem.ENDFILE:
                    System.out.println("EOF");
                    break;
                case LexItem.ERROR:
                    System.out.println("ERROR: " + tokenList.get(i).getSeminfo());
                    break;
                case LexItem.COMMENT:
                    System.out.println("COMMENT(注释): \n" + tokenList.get(i).getSeminfo()+"\n注释结束");
                    break;
                default:
                    System.out.println("Reserved word: " + tokenList.get(i).getSeminfo());
                    break;
            }
        }
    }

    static List<Character> singleDelimiter = new ArrayList<Character>() {
        {
             add(','); add(';'); add('+'); add('-'); add('*'); add('/'); add('('); add(')');
            add('['); add(']'); add('='); add('<');
        }
    };

    public void formTokenList(String fileContent) throws LexException {
        while(cursor<fileContent.length()){
            Token token = analyzeCode(fileContent);
            tokenList.add(token);
        }
//        tokenList.add(new Token(line,LexItem.ENDFILE,""));

    }

    public Token analyzeCode(String code) throws LexException {
        int curState = 0;
        Token token = new Token(-1,LexItem.ENDFILE,"");
        boolean flag = true;
        while(flag&&cursor<code.length()){
            switch (curState){
                case 0:{
                    if(Character.isLetter(code.charAt(cursor))) curState=1;
                    else if(Character.isDigit(code.charAt(cursor))) curState=2;
                    else if(singleDelimiter.contains(code.charAt(cursor))) curState = 3;
                    else if (code.charAt(cursor) == ':') curState = 4;
                    else if (code.charAt(cursor) == '.') curState = 5;
                    else if (code.charAt(cursor) == '{') curState = 6;
                    else if (code.charAt(cursor) == '\'') curState = 7;
                    else if (code.charAt(cursor) == ' ' || code.charAt(cursor) == '\t') cursor++;
                    else if (code.charAt(cursor) == '\n') {
                        cursor++;line++;
                    }
                    else {
                        token = new Token(line,LexItem.ERROR,Character.toString(code.charAt(cursor)));
                        String msg = "行数: "+line+"\t未知符号: "+code.charAt(cursor);
                        throw new LexException(msg);
//                        cursor++;
//                        flag = false;
                    }
                    break;
                }
                case 1:{
                    StringBuilder content = new StringBuilder();
                    while(Character.isDigit(code.charAt(cursor))||Character.isLetter(code.charAt(cursor))){
                        content.append(code.charAt(cursor));
                        cursor++;
                    }
                    token = new Token(line,isReserved(content.toString()),content.toString());
                    flag = false;
                    break;
                }
                case 2:{
                    StringBuilder content = new StringBuilder();
                    while (Character.isDigit(code.charAt(cursor))) {
                        content.append(code.charAt(cursor));
                        cursor++;
                    }
                    token = new Token(line,LexItem.INTC,content.toString());
                    flag = false;
                    break;
                }
                case 3:{
                    switch (code.charAt(cursor)){
                        case '+': token = new Token(line,LexItem.PLUS,"+");break;
                        case '-': token = new Token(line,LexItem.MINUS,"-");break;
                        case '*': token = new Token(line,LexItem.TIMES,"*");break;
                        case '/': token = new Token(line,LexItem.OVER,"/");break;
                        case '(': token = new Token(line,LexItem.LPAREN,"(");break;
                        case ')': token = new Token(line,LexItem.RPAREN,")");break;
                        case '[': token = new Token(line,LexItem.LMIDPAREN,"[");break;
                        case ']': token = new Token(line,LexItem.RMIDPAREN,"]");break;
                        case ';': token = new Token(line,LexItem.SEMI,";");break;
                        case ',': token = new Token(line,LexItem.COMMA,",");break;
                        case '<': token = new Token(line,LexItem.LT,"<");break;
                        case '=': token = new Token(line,LexItem.EQ,"=");break;
                        default:break;
                    }
                    cursor++;
                    flag = false;
                    break;
                }
                case 4:{
                    if(code.charAt(cursor+1)=='=') {
                        token = new Token(line,LexItem.ASSIGN,":=");
                        cursor++;
                    }
                    else{
                        token = new Token(line,LexItem.ERROR,Character.toString(code.charAt(cursor)));
                    }
                    cursor++;
                    flag = false;
                    break;
                }
                case 5:{
                    if(code.charAt(cursor+1)=='.') {
                        token = new Token(line,LexItem.UNDERANGE,"..");
                        cursor++;
                    }
                    else {
                        token = new Token(line,LexItem.DOT,".");
                    }
                    cursor++;
                    flag = false;
                    break;
                }
                case 6:{
                    StringBuilder content = new StringBuilder();
                    cursor++;
                    while(cursor < code.length() && code.charAt(cursor)!='}'){
                        content.append(code.charAt(cursor));
                        cursor++;
                    }
                    token = new Token(line,LexItem.COMMENT,content.toString());
                    comment++;
                    cursor++;
                    flag = false;
                    break;
                }
                case 7:{
                    int index = code.indexOf('\'',cursor+1);
                    if(index==-1){
                        token = new Token(line,LexItem.ERROR,"\'");
                    }
                    if((index-cursor) == 2) {
                        token = new Token(line,LexItem.INTC,Character.toString(code.charAt(cursor+1)));
                    }
                    if((index-cursor) > 2) {
                        token = new Token(line,LexItem.ERROR,code.substring(cursor,index+1));
                    }
                    cursor = index == -1 ? cursor+1 : index+1;
                    flag = false;
                    break;
                }
            }
        }
        return token;
    }

}
