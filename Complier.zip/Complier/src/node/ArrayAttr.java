package node;

public class ArrayAttr extends Attr{
    public String low;
    public String high;
    public String typename; //数组元素类型
    public ArrayAttr(){
        this.low = "";
        this.high = "";
        this.typename = "";
    }
}
