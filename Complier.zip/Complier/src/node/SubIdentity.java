package node;

public class SubIdentity {
    //nodeKind=DecK时为 ArrayK,CharK,IntegerK,RecordK,IdK 之一
    //nodeKind=StmtK时为 ifK,WhileK,AssignK,ReadK,WriteK,CallK,ReturnK 之一
    //nodeKind=ExpK时为 OpK,ConstK,IdK 之一
    public static final int  ArrayK = 1;
    public static final int  CharK = 2;
    public static final int  IntegerK = 3;
    public static final int  RecordK = 4;
    public static final int  IdK = 5;
    public static final int  IfK = 6;
    public static final int  WhileK = 7;
    public static final int  AssignK = 8;
    public static final int  ReadK = 9;
    public static final int  WriteK = 10;
    public static final int  CallK = 11;
    public static final int  ReturnK = 12;
    public static final int  OpK = 13;
    public static final int  ConstK = 14;
    public static final int  ParamK = 15;

}
