package tools;

import lex.Token;
import lex.WordAutomat;
import syntax.SyntaxAnalysis;
import utils.FileReader;
import utils.LexException;
import utils.SyntaxException;

import java.io.IOException;
import java.util.List;

public class demo {
    public static void main(String[] args) throws IOException, LexException {
        FileReader fileReader = new FileReader();
        String code = fileReader.loadContentOfFile("resources/testcode2.txt");
        WordAutomat automat = new WordAutomat();
        try {
            automat.formTokenList(code);
        }catch (LexException e){
            e.printStackTrace();
        }
//        List<Token> tokenList = automat.getTokenList();
        automat.displayTokenList();
        SyntaxAnalysis analysis = new SyntaxAnalysis(automat);
        try {
            analysis.parserByPredictTable();
        } catch (SyntaxException e) {
            e.printStackTrace();
        }
        System.out.println();
    }
}
