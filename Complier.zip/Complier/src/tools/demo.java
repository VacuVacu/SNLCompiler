package tools;

import lex.Token;
import lex.WordAutomat;
import syntax.SyntaxAnalysis;
import utils.FileReader;

import java.io.IOException;
import java.util.List;

public class demo {
    public static void main(String[] args) throws IOException {
        FileReader fileReader = new FileReader();
        String code = fileReader.loadContentOfFile("resources/testcode2.txt");
        WordAutomat automat = new WordAutomat();
        automat.formTokenList(code);
//        List<Token> tokenList = automat.getTokenList();
        automat.displayTokenList();
        SyntaxAnalysis analysis = new SyntaxAnalysis(automat);
        analysis.parserByPredictTable();
        System.out.println();
    }
}
