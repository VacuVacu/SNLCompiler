package lex;

//保留字
public class ReservedWord {
    private int lexType;
    private String content;

    public ReservedWord(int lexType, String content) {
        this.lexType = lexType;
        this.content = content;
    }

    public int getLexType() {
        return lexType;
    }

    public void setLexType(int lexType) {
        this.lexType = lexType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

