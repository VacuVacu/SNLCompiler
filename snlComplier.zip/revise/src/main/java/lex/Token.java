package lex;

public class Token {
    int line=-1;
    int lexType=0;
    String seminfo;

    public Token(int line, int lexType, String seminfo) {
        this.line = line;
        this.lexType = lexType;
        this.seminfo = seminfo;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line = line;
    }

    public int getLexType() {
        return lexType;
    }

    public void setLexType(int lexType) {
        this.lexType = lexType;
    }

    public String getSeminfo() {
        return seminfo;
    }

    public void setSeminfo(String seminfo) {
        this.seminfo = seminfo;
    }
}
