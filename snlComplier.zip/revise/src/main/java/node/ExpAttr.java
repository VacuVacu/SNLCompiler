package node;

public class ExpAttr extends Attr{
   public int LexItem;
   public String val;  // varKind=IdV||ArrayMembV||FieldMembV时 val为变量名 否则为数字因子 存储数字字符串
   public VarKind varKind;  //为0代表数字因子  为IdV 1  ArrayMembV 2  FieldMembV 3  过程 4
//   public int type;  //取值为Bool 0 Integer 1 Void 2 之一为 表达式检查类型  构建分析表再查吧
   
   public ExpAttr() {
      varKind = VarKind.ConstV;
   }

   public int getLexItem() {
      return LexItem;
   }
}
