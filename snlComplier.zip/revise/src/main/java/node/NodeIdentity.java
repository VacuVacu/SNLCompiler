package node;

public class NodeIdentity {
    //节点类型可为 ProK(程序) PheadK(程序头) TypeK(类型) VarK(变量) ProcDecK(过程声明) StmLK DecK(声明) StmtK(语句) ExpK(表达式）
    public static final int ProK = 1;
    public static final int PheadK = 2;
    public static final int TypeK = 3;
    public static final int VarK = 4;
    public static final int ProcDecK = 5;
    public static final int StmLK = 6;
    public static final int DecK = 7;
    public static final int StmtK = 8;
    public static final int ExpK = 9;

    public static String getIdentity(int i) {
        if (i == 1) return "ProK";
        else if (i == 2) return "PheadK";
        else if (i == 3) return "TypeK";
        else if (i == 4) return "VarK";
        else if (i == 5) return "ProcDecK";
        else if (i == 6) return "StmLK";
        else if (i == 7) return "DecK";
        else if (i == 8) return "StmtK";
        else if (i == 9) return "ExpK";
        return null;
    }
}
