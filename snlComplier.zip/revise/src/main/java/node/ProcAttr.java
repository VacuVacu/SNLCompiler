package node;

import java.util.ArrayList;
import java.util.List;

public class ProcAttr extends Attr{
    public List<String> name;  //参数名
    public List<String> type;  //参数类型
    public List<Boolean> isVariable;  //是否是变参 变参为1
    public int index=0; //参数下标
    public ProcAttr(){
        this.name = new ArrayList<>();
        this.type = new ArrayList<>();
        this.isVariable = new ArrayList<>();
        index=0;
    }
}
