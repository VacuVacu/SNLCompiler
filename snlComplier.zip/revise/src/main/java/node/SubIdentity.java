package node;

public class SubIdentity {
    //nodeKind=DecK时为 ArrayK,CharK,IntegerK,RecordK,IdK 之一
    //nodeKind=StmtK时为 ifK,WhileK,AssignK,ReadK,WriteK,CallK,ReturnK 之一
    //nodeKind=ExpK时为 OpK,ConstK,IdK 之一
    public static final int  ArrayK = 1;
    public static final int  CharK = 2;
    public static final int  IntegerK = 3;
    public static final int  RecordK = 4;
    public static final int  IdK = 5;
    public static final int  IfK = 6;
    public static final int  WhileK = 7;
    public static final int  AssignK = 8;
    public static final int  ReadK = 9;
    public static final int  WriteK = 10;
    public static final int  CallK = 11;
    public static final int  ReturnK = 12;
    public static final int  OpK = 13;
    public static final int  ConstK = 14;
    public static final int  ParamK = 15;

    public static String getIdentity(int i) {
        if (i == 1) return "ArrayK";
        else if (i == 2) return "CharK";
        else if (i == 3) return "IntegerK";
        else if (i == 4) return "RecordK";
        else if (i == 5) return "IdK";
        else if (i == 6) return "IfK";
        else if (i == 7) return "WhileK";
        else if (i == 8) return "AssignK";
        else if (i == 9) return "ReadK";
        else if (i == 10) return "WriteK";
        else if (i == 11) return "CallK";
        else if (i == 12) return "ReturnK";
        else if (i == 13) return "OpK";
        else if (i == 14) return "ConstK";
        else if (i == 15) return "ParamK";
        return null;
    }
}
