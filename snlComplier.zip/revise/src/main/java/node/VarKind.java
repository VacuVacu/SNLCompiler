package node;

public enum VarKind {
    ConstV, IdV, ArrayMembV, FieldMembV, ProcV
}
