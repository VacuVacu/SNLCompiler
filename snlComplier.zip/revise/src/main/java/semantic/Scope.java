package semantic;

import com.fasterxml.jackson.databind.ObjectMapper;
import semantic.entry.AttributeIr;
import semantic.entry.SymbTable;

import java.util.ArrayList;
import java.util.List;

public class Scope {
    public List<List<SymbTable>> symbTableStack;
    public List<Integer> offsetList;

    public Scope() {
        symbTableStack = new ArrayList<>();
        offsetList = new ArrayList<>();
    }

    public void createTable() {
        symbTableStack.add(new ArrayList<SymbTable>());
        offsetList.add(0);
    }

    public void destroyTable() {
        System.out.println("\nDestroy symbol Table: " + (symbTableStack.size() - 1));
        printSymbTable(symbTableStack.size() - 1);
        symbTableStack.remove(symbTableStack.size() - 1);
        offsetList.remove(offsetList.size() - 1);
    }

    // flag为true: 查找全表; flag为false: 查找当前表
    public SymbTable findEntry(String id, boolean flag) {
        if (flag) {
            for (int i = symbTableStack.size() - 1; i >= 0; i--)
                for (SymbTable symbTable : symbTableStack.get(i))
                    if (symbTable.idName.equals(id))
                        return symbTable;
        }
        else {
            for (SymbTable symbTable : symbTableStack.get(symbTableStack.size() - 1))
                if (symbTable.idName.equals(id))
                    return symbTable;
        }
        return null;
    }

    public SymbTable enter(String id, AttributeIr attribP) {
        SymbTable entry = findEntry(id, false);
        if (entry == null) {
            SymbTable symbTable = new SymbTable(id, attribP);
            symbTableStack.get(symbTableStack.size() - 1).add(symbTable);
            return symbTable;
        }
        System.out.println("标识符 " + id + " 重复声明");
        return null;
    }

    public void printSymbTable(int i) {
        try {
            for (SymbTable s : symbTableStack.get(i)) {
//                    System.out.println("\nSymbTable: ");
//                    ObjectMapper objectMapper = new ObjectMapper();
//                    System.out.println(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(s));
                System.out.println(s);
            }
            System.out.println("\nLevel: " + i + " Offset: " + offsetList.get(i));
            System.out.println("----------------------------------------");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "Scope{" +
                "symbTableStack=" + symbTableStack +
                '}';
    }
}
