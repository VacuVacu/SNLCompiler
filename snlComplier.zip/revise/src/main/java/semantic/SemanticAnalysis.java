package semantic;

import node.*;
import semantic.entry.*;

import java.util.ArrayList;
import java.util.List;

public class SemanticAnalysis {
    public Scope scope;
    public TypeIr intPtr;
    public TypeIr charPtr;

    public void analysis(TreeNode t) {
        initialize();

        if (t.children[1] != null) {
            TreeNode child = t.children[1].children[0];
            typeDecPart(child);
        }

        if (t.children[2] != null) {
            TreeNode child = t.children[2].children[0];
            varDecList(child);
        }

        TreeNode child = t.children[3];
        procDecPart((child));

        child = t.children[4].children[0];
        body(child);
        scope.destroyTable();
        System.out.println("\n语义分析完成");
    }

    public void initialize() {
        scope = new Scope();
        scope.createTable();
        intPtr = new TypeIr();
        intPtr.kind = TypeKind.INT_TY;
        intPtr.size = 1;
        charPtr = new TypeIr();
        charPtr.kind = TypeKind.CHAR_TY;
        charPtr.size = 1;
    }

    public TypeIr typeProcess(TreeNode t) {
        if (t.nodeKind == NodeIdentity.DecK) {
            if (t.subKind == SubIdentity.IntegerK) return intPtr;
            else if (t.subKind == SubIdentity.CharK) return charPtr;
            else if (t.subKind == SubIdentity.ArrayK) return arrayType(t);
            else if (t.subKind == SubIdentity.RecordK) return recordType(t);
            else if (t.subKind == 0) {
                if (t.typeName.equals("Integer")) return intPtr;
                else if (t.typeName.equals("Char")) return charPtr;
                else return scope.findEntry(t.typeName, true).attrIr.idType;
            }
        }
        return null;
    }

//    public TypeIr nameType(TreeNode t) {
//        SymbTable entry = scope.findEntry(t.name.get(0), true);
//        if (entry == null) {
//            System.out.println("Lind " + t.line + ": " + t.name.get(0) + " 无声明错误");
//            return null;
//        }
//        if (entry.attrIr.kind == IdKind.TYPE_KIND) {
//            System.out.println("Lind " + t.line + ": " + t.name.get(0) + " 非类型标识错误");
//            return null;
//        }
//        return entry.attrIr.idType;
//    }

    public TypeIr arrayType(TreeNode t) {
        ArrayAttr arrayAttr = (ArrayAttr) t.attr;
        if (Integer.parseInt(arrayAttr.low) < Integer.parseInt(arrayAttr.high)) {
            ArrayPtr arrayPtr = new ArrayPtr();
            arrayPtr.indexTy = intPtr;
            arrayPtr.elemTy = arrayAttr.typename.equals("Integer") ? intPtr : charPtr;
            arrayPtr.kind = TypeKind.ARRAY_TY;
            arrayPtr.size = Integer.parseInt(arrayAttr.high) - Integer.parseInt(arrayAttr.low);
            return arrayPtr;
        }
        System.out.println("Lind " + t.line + ": " + t.name + "下标越界错误");
        return null;
    }

    public TypeIr recordType(TreeNode t) {
        RecordPtr recordPtr = new RecordPtr();
        recordPtr.kind = TypeKind.RECORD_TY;

        TreeNode filedNode = t.children[0];
        int offset = 0;
        while (filedNode != null) {
            TypeIr typeIr = typeProcess(filedNode);
            for (String name : filedNode.name) {
                recordPtr.body.add(new FieldChain(name, typeIr, offset));
                offset += typeIr.size;
            }
            filedNode = filedNode.sibling;
        }
        recordPtr.size = offset;
        return recordPtr;
    }

    public void typeDecPart(TreeNode t) {
        while (t != null) {
            SymbTable entry = scope.enter(t.name.get(0), new AttributeIr(typeProcess(t), IdKind.TYPE_KIND));
            if (entry == null)
                System.out.println("Lind " + t.line + ": " + t.name + " 重复声明错误");
            t = t.sibling;
        }
    }

    public void varDecList(TreeNode t) {
        while (t != null) {
            for (String name : t.name) {
                VarAttributeIr varAttributeIr = new VarAttributeIr();
                varAttributeIr.idType = typeProcess(t);
                varAttributeIr.level = scope.symbTableStack.size() - 1;
                varAttributeIr.kind = IdKind.VAR_KIND;
                varAttributeIr.access = (t.subKind == SubIdentity.ArrayK || t.subKind == SubIdentity.RecordK);
                varAttributeIr.off = scope.offsetList.get(varAttributeIr.level);
                SymbTable entry = scope.enter(name, varAttributeIr);
                if (entry == null)
                    System.out.println("Lind " + t.line + ": " + name + " 重复声明错误");
                scope.offsetList.set(varAttributeIr.level, varAttributeIr.off + varAttributeIr.idType.size);
            }
            t = t.sibling;
        }
    }

    public void procDecPart(TreeNode t) {
        while (t != null) {
            SymbTable symbTable = headProcess(t);
            ProcAttributeIr procAttributeIr = (ProcAttributeIr) symbTable.attrIr;
            procAttributeIr.param = paraDecList(t);

            if (t.children[1] != null) {
                TreeNode child = t.children[1].children[0];
                typeDecPart(child);
            }

            if (t.children[2] != null) {
                TreeNode child = t.children[2].children[0];
                varDecList(child);
            }

            TreeNode child = t.children[3];
            procDecPart((child));

            child = t.children[4].children[0];
            body(child);
            scope.destroyTable();

            t = t.sibling;
        }
    }

    public SymbTable headProcess(TreeNode t) {
        ProcAttributeIr procAttributeIr = new ProcAttributeIr();
        procAttributeIr.kind = IdKind.PROC_KIND;
        procAttributeIr.level = scope.symbTableStack.size() - 1;
        procAttributeIr.idType = null;
        return scope.enter(t.name.get(0), procAttributeIr);
    }

    public List<SymbTable> paraDecList(TreeNode t) {
        scope.createTable();
        List<SymbTable> param = new ArrayList<>();
        ProcAttr procAttr = (ProcAttr) t.attr;
        for (int i = 0; i < procAttr.type.size(); i++) {
            VarAttributeIr varAttributeIr = new VarAttributeIr();
            if (procAttr.type.get(i).equals("Integer"))
                varAttributeIr.idType = intPtr;
            else if (procAttr.type.get(i).equals("Char"))
                varAttributeIr.idType = charPtr;
            varAttributeIr.level = scope.symbTableStack.size() - 1;
            varAttributeIr.kind = IdKind.VAR_KIND;
            varAttributeIr.access = !procAttr.isVariable.get(i);
            varAttributeIr.off = scope.offsetList.get(varAttributeIr.level);
            SymbTable entry = scope.enter(procAttr.name.get(i), varAttributeIr);
            if (entry == null)
                System.out.println("Lind " + t.line + ": " + procAttr.name.get(i) + " 重复声明错误");
            scope.offsetList.set(varAttributeIr.level, varAttributeIr.off + varAttributeIr.idType.size);
            param.add(entry);
        }
        return param;
    }

    public void body(TreeNode t) {
        while (t != null) {
            statement(t);
            t = t.sibling;
        }
    }

    public void statement(TreeNode t) {
        if (t.nodeKind == NodeIdentity.StmtK) {
            if (t.subKind == SubIdentity.IfK) ifStatement(t);
            else if (t.subKind == SubIdentity.WhileK) whileStatement(t);
            else if (t.subKind == SubIdentity.AssignK) assignStatement(t);
            else if (t.subKind == SubIdentity.ReadK) readStatement(t);
            else if (t.subKind == SubIdentity.WriteK) writeStatement(t);
            else if (t.subKind == SubIdentity.CallK) callStatement(t);
        }
    }

    public void ifStatement(TreeNode t) {
        body(t.children[1]);
        body(t.children[2]);
    }

    public void whileStatement(TreeNode t) {
        body(t.children[1]);
    }

    public void assignStatement(TreeNode t) {
        TypeIr typeIr = expr(t.children[0].sibling, new VarAttributeIr());

        if (t.children[0].nodeKind == NodeIdentity.ExpK) {
            ExpAttr expAttr = (ExpAttr) t.children[0].attr;
            SymbTable entry = scope.findEntry(expAttr.val, true);
            if (expAttr.varKind == VarKind.IdV && entry != null && typeIr.equals(entry.attrIr.idType)) return;
            if (expAttr.varKind == VarKind.ArrayMembV && typeIr.equals(arrayVar(t.children[0]))) return;
            if (expAttr.varKind == VarKind.FieldMembV && typeIr.equals(recordVar(t.children[0]))) return;
            System.out.println("Lind " + t.line + ": " + " 赋值语法错误");
        }
    }

    public void readStatement(TreeNode t) {
        SymbTable entry = scope.findEntry(t.name.get(0), true);
        if (entry == null)
            System.out.println("Lind " + t.line + ": " + t.name.get(0) + " 标识符未找到");
        else if (entry.attrIr.kind != IdKind.VAR_KIND)
            System.out.println("Lind " + t.line + ": " + t.name.get(0) + " 标识符不为变量");
    }

    public void writeStatement(TreeNode t) {
        if (t.children[0].subKind == SubIdentity.OpK) return;
        if (t.children[0].nodeKind == NodeIdentity.ExpK) {
            ExpAttr expAttr = (ExpAttr) t.children[0].attr;
            if (expAttr.varKind != VarKind.ProcV) return;
        }
        System.out.println("Lind " + t.line + ": " + "write语句表达式类型不合法");
    }

    public void callStatement(TreeNode t) {
        ExpAttr procAttr = (ExpAttr) t.children[0].attr;
        SymbTable entry = scope.findEntry(procAttr.val, true);
        if (entry == null || entry.attrIr.kind != IdKind.PROC_KIND) {
            System.out.println("Lind " + t.line + ": " + procAttr.val + " 找不到该过程");
            return;
        }
        ProcAttributeIr procAttributeIr = (ProcAttributeIr) entry.attrIr;
        TreeNode param = t.children[0].children[0];
        if (procAttributeIr.param.size() == 0 && param == null) return;
        if (procAttributeIr.param.size() == 1 && param != null && param.children[1] == null) return;

        param = param.children[1];
        for (int i = 1; i < procAttributeIr.param.size(); i++) {
            if (param == null) {
                System.out.println("Lind " + t.line + ": " + "参数不匹配");
                return;
            }
            param = param.children[1];
        }
        if (param != null) System.out.println("Lind " + t.line + ": " + "参数不匹配");
    }

    TypeIr expr(TreeNode t, VarAttributeIr v) {
        if (t.nodeKind == NodeIdentity.ExpK) {
            if (t.subKind == SubIdentity.OpK) {
                TypeIr expr0 = expr(t.children[0], new VarAttributeIr());
                TypeIr expr1 = expr(t.children[1], new VarAttributeIr());
                if (expr0.equals(expr1))
                    return expr0;
                System.out.println("Lind " + t.line + ": " + "运算符两侧类型不同");
                return null;
            }
            ExpAttr expAttr = (ExpAttr) t.attr;
            if (expAttr.varKind == VarKind.ConstV) {
                t.nodeKind = NodeIdentity.DecK;
                t.subKind = SubIdentity.IntegerK;
                v.access = true;
                return typeProcess(t);
            } else if (expAttr.varKind == VarKind.IdV) {
                SymbTable entry = scope.findEntry(t.name.get(0), true);
                if (entry.attrIr.kind != IdKind.VAR_KIND) {
                    System.out.println("Lind " + t.line + ": " + t.name.get(0) + " 不是变量");
                    return null;
                }
                v.access = true;
                return entry.attrIr.idType;
            } else if (expAttr.varKind == VarKind.ArrayMembV)
                return arrayVar(t);
            else if (expAttr.varKind == VarKind.FieldMembV)
                return recordVar(t);
        }
        return null;
    }

    TypeIr arrayVar(TreeNode t) {
        ExpAttr expAttr = (ExpAttr) t.attr;
        SymbTable entry = scope.findEntry(expAttr.val, true);
        if (entry == null) {
            System.out.println("Lind " + t.line + ": " + expAttr.val + " 标识符未找到");
            return null;
        }
        if (expAttr.varKind != VarKind.ArrayMembV) {
            System.out.println("Lind " + t.line + ": " + expAttr.val + " 标识符不是数组变量");
            return null;
        }
        if (t.children[0].subKind == SubIdentity.ConstK)
            return intPtr;

        ExpAttr indexAttr = (ExpAttr) t.children[0].attr;
        SymbTable indexEntry = scope.findEntry(indexAttr.val, true);
        if (indexEntry.attrIr.idType.equals(entry.attrIr.idType))
            return indexEntry.attrIr.idType;

        System.out.println("Lind " + t.line + ": " + indexAttr.val + " 下标类型不相符");
        return null;
    }

    TypeIr recordVar(TreeNode t) {
        ExpAttr expAttr = (ExpAttr) t.attr;
        SymbTable entry = scope.findEntry(expAttr.val, true);
        if (entry == null) {
            System.out.println("Lind " + t.line + ": " + expAttr.val + " 标识符未找到");
            return null;
        }
        if (expAttr.varKind != VarKind.FieldMembV) {
            System.out.println("Lind " + t.line + ": " + expAttr.val + " 标识符不是记录变量");
            return null;
        }
        RecordPtr recordPtr = (RecordPtr) entry.attrIr.idType;
        ExpAttr fieldAttr = (ExpAttr) t.children[0].attr;
        FieldChain field = recordPtr.findField(fieldAttr.val);
        if (field == null) {
            System.out.println("Lind " + t.line + ": " + fieldAttr.val + " 非法域名");
            return null;
        }
        return field.unitType;
    }
}
