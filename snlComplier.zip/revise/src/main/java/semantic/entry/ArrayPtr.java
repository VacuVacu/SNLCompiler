package semantic.entry;

public class ArrayPtr extends TypeIr{
    public TypeIr indexTy;
    public TypeIr elemTy;

    @Override
    public String toString() {
        return "\nArrayPtr{" +
                "indexTy=" + indexTy +
                ", elemTy=" + elemTy +
                ", size=" + size +
                ", kind=" + kind +
                '}';
    }
}
