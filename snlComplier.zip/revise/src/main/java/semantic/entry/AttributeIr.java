package semantic.entry;

public class AttributeIr {
    public TypeIr idType;
    public IdKind kind;

    public AttributeIr() {
    }

    public AttributeIr(TypeIr idType, IdKind kind) {
        this.idType = idType;
        this.kind = kind;
    }

    @Override
    public String toString() {
        return "\nAttributeIr{" +
                "idType=" + idType +
                ", kind=" + kind +
                '}';
    }
}
