package semantic.entry;

public class FieldChain {
    public String idName;
    public TypeIr unitType;
    public int offset;

    public FieldChain(String idName, TypeIr unitType, int offset) {
        this.idName = idName;
        this.unitType = unitType;
        this.offset = offset;
    }

    @Override
    public String toString() {
        return "\nFieldChain{" +
                "idName='" + idName + '\'' +
                ", unitType=" + unitType +
                ", offset=" + offset +
                '}';
    }
}
