package semantic.entry;

public enum IdKind {
    TYPE_KIND,
    VAR_KIND,
    PROC_KIND,
}
