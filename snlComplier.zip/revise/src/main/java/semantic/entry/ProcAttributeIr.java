package semantic.entry;

import java.util.List;

public class ProcAttributeIr extends AttributeIr {
    public int level;
    public List<SymbTable> param; // 参数表
    public int code;
    public int size;

    @Override
    public String toString() {
        return "\nProcAttributeIr{" +
                "idType=" + idType +
                ", kind=" + kind +
                ", level=" + level +
                ", param=" + param +
                ", code=" + code +
                ", size=" + size +
                '}';
    }
}
