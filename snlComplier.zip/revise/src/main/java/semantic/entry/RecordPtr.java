package semantic.entry;

import java.util.ArrayList;
import java.util.List;

public class RecordPtr extends TypeIr{
    public List<FieldChain> body;

    public RecordPtr() {
        body = new ArrayList<>();
    }

    public FieldChain findField(String id) {
        for (FieldChain fieldChain : body)
            if (fieldChain.idName.equals(id))
                return fieldChain;
        return null;
    }

    @Override
    public String toString() {
        return "\nRecordPtr{" +
                "body=" + body +
                ", size=" + size +
                ", kind=" + kind +
                '}';
    }
}
