package semantic.entry;

public class SymbTable {
    public String idName;
    public AttributeIr attrIr;

    public SymbTable() {
    }

    public SymbTable(String idName, AttributeIr attrIr) {
        this.idName = idName;
        this.attrIr = attrIr;
    }

    @Override
    public String toString() {
        return "\nSymbTable{" +
                "idName='" + idName + '\'' +
                ", attrIr=" + attrIr +
                '}';
    }
}
