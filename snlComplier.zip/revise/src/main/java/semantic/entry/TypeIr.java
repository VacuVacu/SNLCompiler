package semantic.entry;

public class TypeIr {
    public int size;
    public TypeKind kind;

    @Override
    public String toString() {
        return "\nTypeIr{" +
                "size=" + size +
                ", kind=" + kind +
                '}';
    }
}
