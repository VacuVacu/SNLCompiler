package semantic.entry;

public enum TypeKind {
    INT_TY,
    CHAR_TY,
    ARRAY_TY,
    RECORD_TY,
    BOOL_TY,
}
