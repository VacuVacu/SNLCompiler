package semantic.entry;

public class VarAttributeIr extends AttributeIr {
    public boolean access; // true 直接变量; false 间接变量
    public int level;
    public int off;

    @Override
    public String toString() {
        return "\nVarAttributeIr{" +
                "idType=" + idType +
                ", kind=" + kind +
                ", access=" + access +
                ", level=" + level +
                ", off=" + off +
                '}';
    }
}
