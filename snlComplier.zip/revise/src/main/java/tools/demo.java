package tools;

import lex.WordAutomat;
import node.TreeNode;
import semantic.SemanticAnalysis;
import syntax.SyntaxAnalysis;
import utils.FileReader;
import utils.Gui;
import utils.LexException;
import utils.SyntaxException;

import java.io.IOException;

public class demo {
    public static void main(String[] args) throws IOException, LexException {
        FileReader fileReader = new FileReader();
        String code = fileReader.loadContentOfFile("src/main/resources/testcode2.txt");
        WordAutomat automat = new WordAutomat();
        try {
            automat.formTokenList(code);
        }catch (LexException e){
            e.printStackTrace();
        }
        automat.displayTokenList();
        SyntaxAnalysis analysis = new SyntaxAnalysis(automat);
        try {
            analysis.parserByPredictTable();
        } catch (SyntaxException|LexException e) {
            e.printStackTrace();
            return;
        }
        System.out.println();

        TreeNode root = analysis.getRoot();
        Gui.showTree(root);

        SemanticAnalysis semanticAnalysis = new SemanticAnalysis();
        semanticAnalysis.analysis(root);
    }
}
