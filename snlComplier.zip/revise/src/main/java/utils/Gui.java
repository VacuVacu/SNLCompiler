package utils;

import node.NodeIdentity;
import node.SubIdentity;
import node.TreeNode;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;

public class Gui {

    public static void showTree(TreeNode root) {
        JFrame jFrame = new JFrame("语法树");
        jFrame.setSize(500, 500);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel jPanel = new JPanel(new BorderLayout());

        DefaultMutableTreeNode tree = new DefaultMutableTreeNode(NodeIdentity.getIdentity(root.nodeKind));
        buildTree(tree, root);

        JTree jTree = new JTree(tree);
        jTree.setShowsRootHandles(true);

        // 创建滚动面板，包裹树（因为树节点展开后可能需要很大的空间来显示，所以需要用一个滚动面板来包裹）
        JScrollPane scrollPane = new JScrollPane(jTree);

        // 添加滚动面板到那内容面板
        jPanel.add(scrollPane, BorderLayout.CENTER);

        // 设置窗口内容面板并显示
        jFrame.setContentPane(jPanel);
        jFrame.setVisible(true);
    }

    public static void buildTree(DefaultMutableTreeNode parentTree, TreeNode parentNode) {
        if (parentNode == null)
            return;
        for (TreeNode child : parentNode.children) {
            while (child != null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(NodeIdentity.getIdentity(child.nodeKind));
                if (SubIdentity.getIdentity(child.subKind) != null)
                    stringBuilder.append(" -- ").append(SubIdentity.getIdentity(child.subKind));
                if (child.typeName != null)
                    stringBuilder.append(" -- ").append(child.typeName).append(": ");
                for (String s : child.name)
                    stringBuilder.append(" -- ").append(s);
                DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(stringBuilder.toString());
                parentTree.add(childNode);
                buildTree(childNode, child);
                child = child.sibling;
            }
        }
    }

}
