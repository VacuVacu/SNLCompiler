package utils;

public class LexException extends Exception{
    public LexException(String message){
        super(message);
    }
}
